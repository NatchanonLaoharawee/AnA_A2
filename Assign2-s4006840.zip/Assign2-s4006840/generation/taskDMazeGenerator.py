# -------------------------------------------------------------------
# PLEASE UPDATE THIS FILE.
# Implementation of Task D maze generator.
#
# __author__ = 'Jeffrey Chan'
# __copyright__ = 'Copyright 2024, RMIT University'
# -------------------------------------------------------------------


from maze.maze3D import Maze3D
from maze.util import Coordinates3D
from generation.mazeGenerator import MazeGenerator


class TaskDMazeGenerator(MazeGenerator):
    """
    TODO: Complete the implementation (Task D)
    """
	
    def generateMaze(self, maze:Maze3D):
        # TODO: Implement this method for task A.
        pass
		
        
        
		